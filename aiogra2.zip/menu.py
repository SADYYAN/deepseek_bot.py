from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

def admin_main_menu():
    buttons = [
        [KeyboardButton(text="🔍 API balansy gör"), KeyboardButton(text="📨 Ulanyjylara habar")],
        [KeyboardButton(text="📦 Zakaz goý"), KeyboardButton(text="🆔 Hyzmat ID sanawy")]
    ]
    return ReplyKeyboardMarkup(keyboard=buttons, resize_keyboard=True)