import json
from aiogram import Router, F
from aiogram.types import Message
from utils.admin_check import is_admin

router = Router()

@router.message(F.text.startswith("📨"))
async def broadcast_prompt(message: Message):
    if is_admin(message):
        await message.answer("Habar mazmunyny ýazyň, ähli ulanyjylara ugradylar.")

@router.message()
async def broadcast_message(message: Message):
    if is_admin(message.reply_to_message) and message.reply_to_message.text.startswith("📨"):
        with open("database/users.json", "r") as f:
            users = json.load(f)

        count = 0
        for user_id in users:
            try:
                await message.bot.send_message(chat_id=int(user_id), text=message.text)
                count += 1
            except:
                continue

        await message.answer(f"Habar {count} ulanyja ugradyldy.")