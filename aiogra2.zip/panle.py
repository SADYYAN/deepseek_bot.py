from aiogram import Router, F
from aiogram.types import Message
from keyboards.admin_menu import admin_main_menu
from utils.admin_check import is_admin

router = Router()

@router.message(F.text == "/admin")
async def admin_panel(message: Message):
    if is_admin(message):
        await message.answer("Admin paneline hoş geldiňiz. Işlejek bölümi saýlaň:", reply_markup=admin_main_menu())
    else:
        await message.answer("Siziň rugsadyňyz ýok!")