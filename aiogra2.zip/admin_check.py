from aiogram.types import Message

ADMINS = [6961049578]  # Telegram ID Adminleriň

def is_admin(message: Message) -> bool:
    return message.from_user.id in ADMINS